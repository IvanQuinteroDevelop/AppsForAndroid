package com.example.practicapp.models

data class Character(var name: String, var thumbnail: Thumbnail)