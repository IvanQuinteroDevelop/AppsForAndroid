package com.example.practicapp.models

class Thumbnail(var path: String, var extension: String) {
}