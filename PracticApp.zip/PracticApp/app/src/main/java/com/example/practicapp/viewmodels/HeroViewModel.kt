package com.example.practicapp.viewmodels


import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.practicapp.models.Character
import com.example.practicapp.repositories.RepositoryAPI
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import retrofit2.Response
import javax.inject.Inject

class HeroViewModel @Inject constructor(var repositoryAPI: RepositoryAPI): ViewModel() {
    private val apiKey = ""
    private val ts = 1
    private val hash = ""
    private val disposable = CompositeDisposable()
    private val responseCharacters = MutableLiveData<Response<ArrayList<Character>>>()


    fun getCharactersMarvel(){

        /*disposable.add(repositoryAPI.getCharacters(ts, hash, apiKey)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe {
                responseCharacters.setValue(Response.success())
            }

        )*/
    }



}